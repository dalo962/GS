spool /gcti/bake/batch/cron_day_hist_purge.log;

select 'Start Time: ' || to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss') from dual;

--'&1' : ��¥ YYYYMMDD
-------------------------------------------------------------------------------------------------------------

set serveroutput on

-- TimeStamp �� ������ ���� ������ �����Ѵ�.
alter session set nls_timestamp_format='YYYY-MM-DD HH24:MI:SS';

DELETE
FROM 	bake.ax_sk_agent_skill_hist
where 	updated_date <= '&1';	

DELETE
FROM 	bake.ax_sk_grp_hist
where 	to_char(row_date,'yyyymmdd') <= '&1';	

select 'END   Time: ' || to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss') from dual;
spool off;

exit;
